# Chatbot Factory

#### An implementation of [ChatterBot](https://github.com/gunthercox/ChatterBot) and [Flask-ChatterBot](https://github.com/chamkank/flask-chatterbot).
